package in.sp.main;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import in.sp.main.entities.Student;
import in.sp.main.services.StudentService;
import in.sp.main.services.StudentServiceImpl;

@SpringBootApplication
public class SpringBootDataJpa1Application {

	public static void main(String[] args) 
	{
		ApplicationContext context =  SpringApplication.run(SpringBootDataJpa1Application.class, args);
	
		StudentService stdService =  context.getBean(StudentServiceImpl.class);
	
//----------------- Insertion -------------------------		
		
		Student std = new Student();
		std.setName("Tush");
		std.setRillno(10);
		std.setMarks(101.2f);
		
		boolean status = stdService.addStudentDetails(std);
		if(status)
		{
			System.out.println("Student Inserted....");
		}
		else
		{
			System.out.println("Student not Found....");
		}
		
		
		
		
//-------------------- Select Operation All ----------------------------
//		List<Student> stdList = stdService.getAllStdDetails();
//		for(Student std : stdList)
//		{
//			System.out.println("Id : "+std.getId());
//			System.out.println("Name : "+std.getName());
//			System.out.println("Roll No : "+std.getRollno());
//			System.out.println("Marks : "+std.getMarks());
//			
//			System.out.println("------------------------------------");
//		}
		
		
		
//-------------------- Select Operation by id ----------------------------	
		
		
		
//		Student std = stdService.getStdDetails(3L);
//		
//		if(std != null) 
//		{
//			System.out.println("Id : "+std.getId());
//			System.out.println("Name : "+std.getName());
//			System.out.println("Roll No : "+std.getRollno());
//			System.out.println("Marks : "+std.getMarks());
//
//		}
//		else
//		{
//			System.out.println("Student Not Found...");
//		}
		
		

		
//-------------------- Update Operations ----------------------------		
		
//	boolean status = stdService.updateStdDetails(1L, 78.6f);
//	if(status)
//	{
//		System.out.println("Marks Updated....");
//	}
//	else 
//	{
//		System.out.println("Not updated");
//	}
	
		
	
//-------------------Delete Operation---------------------------------
		
//		boolean status = stdService.deleteStdDetails(3L);
//		if(status)
//		{
//			System.out.println("Student Deleted....");
//		}
//		else 
//		{
//			System.out.println("Not Deleted");
//		}
		
		
	}
	
}
