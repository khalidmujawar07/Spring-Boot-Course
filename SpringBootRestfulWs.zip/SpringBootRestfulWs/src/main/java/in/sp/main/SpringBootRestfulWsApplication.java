package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestfulWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestfulWsApplication.class, args);
	}

}
