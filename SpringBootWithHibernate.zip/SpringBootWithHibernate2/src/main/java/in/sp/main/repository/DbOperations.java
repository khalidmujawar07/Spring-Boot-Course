package in.sp.main.repository;

import in.sp.main.entities.User;

public interface DbOperations {
	public User getUserDetails(Long id);
}
