package in.sp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.sp.entities.User;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

//		User user1 = new User();
//		user1.setName("Yash");
//		user1.setEmail("yash@gmail.com");
//		user1.setPassword("yash@1234");
//		user1.setGender("male");
//		user1.setCity("Kolhapur");
		
		User user1 = new User();
		user1.setName("Kily");
		user1.setEmail("kily@gmail.com");
		user1.setPassword("Kk@1234");
		user1.setGender("female");
		user1.setCity("Russia");

		Configuration cfg = new Configuration();
		cfg.configure("/in/sp/config/hibernate.cfg.xml");

		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		
//--------------------Insertion -----------------------------------------		
//		try 
//		{
//			session.save(user1);
//		    transaction.commit();  
//		    
//		    System.out.println("User Details added successfully......");
//		} 
//		catch (Exception e) 
//		{
//			transaction.rollback();
//			e.printStackTrace();
//			
//			System.out.println("User Details not added due to some error......");
//		}
		
		
		
//-------------------Select Operation ------------------------------------		
		
//		try  
//		{
//			User user = session.get(User.class,4L);
//			if(user != null) 
//			{
//			 System.out.println(user.getId());
//			 System.out.println(user.getName());
//			 System.out.println(user.getEmail());
//			 System.out.println(user.getPassword());
//			 System.out.println(user.getGender());
//			 System.out.println(user.getCity());
//			}
//			else
//			{
//				System.out.println("user not found....");
//			}
//			
//			
//		} 
//		catch (Exception e) 
//		{
//			e.printStackTrace();		
//		}
		
		
		
		
//--------------------Updation -----------------------------------------	
		
		
//		try 
//		{
//			User user = session.get(User.class,2L);
//			user.setCity("Benglore");
//			
//			session.saveOrUpdate(user);
//		    transaction.commit();  
//		    
//		    System.out.println("User Details Updated successfully......");
//		} 
//		catch (Exception e) 
//		{
//			transaction.rollback();
//			e.printStackTrace();
//			
//			System.out.println("User Details not updated due to some error......");
//		}	
		
//-----------------------------Delete---------------------------------------------
		try 
		{
			User user = new User();
			user.setId(3);
			
			session.delete(user);
		    transaction.commit();  
		    
		    System.out.println("User Deleted successfully......");
		} 
		catch (Exception e) 
		{
			transaction.rollback();
			e.printStackTrace();
			
			System.out.println("User not deleted due to some error......");
		}		
		
		
		
		
		
		
	}
}
