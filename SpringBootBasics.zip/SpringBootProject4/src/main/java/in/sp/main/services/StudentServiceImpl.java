package in.sp.main.services;

import org.springframework.beans.factory.annotation.Autowired;

import in.sp.main.beans.Student;
import in.sp.main.repository.StudentRepository;

public class StudentServiceImpl implements StudentService
{ 
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public boolean addStudentDetails(Student std) {
		boolean status = false;
		try 
		{
			studentRepository.save(std);
			status = true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			status = false;
		}
		
		return status;
	}
	
}


