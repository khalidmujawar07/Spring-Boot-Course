package in.sp.main.services;

import in.sp.main.beans.Student;

public interface StudentService 
{
	public boolean addStudentDetails(Student std);
}
