package in.sp.main;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import in.sp.main.beans.Student;
import in.sp.main.services.StudentService;
import in.sp.main.services.StudentServiceImpl;

@SpringBootApplication
public class SpringBootProject4Application {

	public static void main(String[] args) 
	{
		ApplicationContext context =  SpringApplication.run(SpringBootProject4Application.class, args);
	
		StudentService stdService =  context.getBean(StudentServiceImpl.class);
		
		Student std = new Student();
		
		std.setName("Yash");
		std.setRollno(101);
		std.setMarks(98.5f);
		
		boolean status = stdService.addStudentDetails(std);
		if(status)
		{
			System.out.println("Student Inserted....");
		}
		else
		{
			System.out.println("Student not Found....");
		}
		
	}
	
}
