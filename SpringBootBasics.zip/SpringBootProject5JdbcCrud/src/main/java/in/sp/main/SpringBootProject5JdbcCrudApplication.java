package in.sp.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import in.sp.main.dao.UserDao;
import in.sp.main.entity.User;

@SpringBootApplication
public class SpringBootProject5JdbcCrudApplication implements CommandLineRunner {
    @Autowired
    private UserDao userdao;

    public static void main(String[] args) {
        SpringApplication.run(SpringBootProject5JdbcCrudApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

// ------------------------- Insertion----------------------------------------   	
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter details for 3 users:");
//        for (int i = 1; i <= 3; i++) {
//            System.out.println("Enter details for User " + i + ":");
//
//            System.out.print("Name: ");
//            String name = scanner.nextLine();
//
//            System.out.print("Email: ");
//            String email = scanner.nextLine();
//
//            System.out.print("Gender: ");
//            String gender = scanner.nextLine();
//
//            System.out.print("City: ");
//            String city = scanner.nextLine();
//
//            User user = new User(name, email, gender, city);
//
//            boolean status = userdao.insertUser(user);
//            if (status) {
//                System.out.println("User " + i + " Inserted Successfully...");
//            } else {
//                System.out.println("User " + i + " not Inserted due to some error...");
//            }
//        }
//        scanner.close();
    
// ----------------------------------Updation 1------------------------------------    
    
//    	  Scanner scanner = new Scanner(System.in);
//
//          System.out.println("Enter email ID of the user to update: ");
//          String email = scanner.nextLine();
//
//          System.out.println("Enter updated details for the user:");
//          System.out.print("Name: ");
//          String name = scanner.nextLine();
//
//          System.out.print("Gender: ");
//          String gender = scanner.nextLine();
//
//          System.out.print("City: ");
//          String city = scanner.nextLine();
//
//          // Create a User object with the updated details
//          User user = new User(name, email, gender, city);
//
//          // Call the updateUser method
//          boolean status = userdao.updateUser(user);
//          if (status) {
//              System.out.println("Updation Successful...");
//          } else {
//              System.out.println("Updation Failed...");
//          }
//          scanner.close();
    
    	
// ----------------------------------Deletion------------------------------------

//		Scanner scanner = new Scanner(System.in);
//		System.out.println("Enter email ID of the user to delete: ");
//		String email = scanner.nextLine();
//
//		boolean status = userdao.DeleteUserByEmail(email);
//		if (status) {
//			System.out.println("Deletion Successful...");
//		} else {
//			System.out.println("Deletion Failed...");
//		}
       
       
//---------------------------------(Select 1 User) - Get User-----------------------------------------  	
       
//    	 Scanner scanner = new Scanner(System.in);
//         System.out.println("Enter email ID: ");
//         String email = scanner.nextLine();
//         User user = userdao.getUserByEmail(email);
//         if (user != null) {
//             System.out.println("----------------------------");
//             System.out.println("Name : " + user.getName());
//             System.out.println("Email : " + user.getEmail());
//             System.out.println("Gender : " + user.getGender());
//             System.out.println("City : " + user.getCity());
//             System.out.println("----------------------------");
//         } else {
//             System.out.println("No user found with email ID: " + email);
//         }
//
//         scanner.close();
       
       
    	//---------------------------------(Select All Users) - List the Users -----------------------------------------  	 
       
       List<User> list = userdao.getAllUsers();
       for(User user: list)
       {
    	   System.out.println("----------------------------");
         System.out.println("Name : " + user.getName());
         System.out.println("Email : " + user.getEmail());
         System.out.println("Gender : " + user.getGender());
         System.out.println("City : " + user.getCity());
         System.out.println("----------------------------");  
       }
    			
       
       
    }
}
